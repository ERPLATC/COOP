Hello there!

First of all, **Thank You** for contributing to Apache Fineract, we're grateful for your interest in our project.

Please do [join our developer mailing list](https://fineract.apache.org/#contribute), as it's where discussions about this project take place - say _Hi_ there!

Our [JIRA Dashboard](https://issues.apache.org/jira/secure/Dashboard.jspa?selectPageId=12335824) is another good way to see what's going on (do create a Login).

Here are a few additional useful pointers:

* https://github.com/apache/fineract/#pull-requests
* https://github.com/apache/fineract/#checkstyle-and-spotless
* https://github.com/apache/fineract/#logging-guidelines
* https://github.com/apache/fineract/#error-handling-guidelines

Note also [our Code of Conduct](CODE_OF_CONDUCT.md).
